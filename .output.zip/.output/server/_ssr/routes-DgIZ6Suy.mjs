//#region node_modules/.nitro/vite/services/ssr/assets/routes-DgIZ6Suy.js
var checkoutUrl = "https://selar.com/s381u81f31";
//#endregion
export { checkoutUrl as t };
