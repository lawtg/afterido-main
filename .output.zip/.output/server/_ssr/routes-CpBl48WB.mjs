import { t as checkoutUrl } from "./routes-DgIZ6Suy.mjs";
import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CpBl48WB.js
var import_jsx_runtime = require_jsx_runtime();
var after_i_do_book_png_asset_default = {
	version: 1,
	asset_id: "b4711773-725f-44de-88eb-b1cb5e009b47",
	project_id: "f1e080b9-5ede-4fc1-b994-2ab751dddf68",
	url: "/__l5e/assets-v1/b4711773-725f-44de-88eb-b1cb5e009b47/after-i-do-book.png",
	r2_key: "a/v1/f1e080b9-5ede-4fc1-b994-2ab751dddf68/b4711773-725f-44de-88eb-b1cb5e009b47/after-i-do-book.png",
	original_filename: "after-i-do-book.png",
	size: 2014474,
	content_type: "image/png",
	created_at: "2026-09-06T16:31:06Z"
};
function PurchaseButton({ label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
		className: "purchase-button",
		href: checkoutUrl,
		children: [
			label,
			" ",
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				"aria-hidden": "true",
				children: "→"
			})
		]
	});
}
function Divider() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "story-divider",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "♥" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {})
		]
	});
}
function SalesPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
			className: "opening",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "page-shell opening-grid",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "opening-copy",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "eyebrow",
							children: "A conversation worth having"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", { children: "The conversation most couples have too late" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "lead",
							children: "There is a conversation many couples have only after they get married."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Sometimes weeks after." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Sometimes months after." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["And sometimes… ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", { children: "not at all." })] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "It’s not about money. It’s not about where they’ll live. It’s not even about children." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "single-line",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "It’s about sex." })
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("figure", {
					className: "book-figure",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: after_i_do_book_png_asset_default.url,
						alt: "After I Do book cover, a guide to sex, intimacy and a healthy sexual relationship in marriage",
						width: "768",
						height: "1152",
						fetchPriority: "high"
					})
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
			className: "page-shell story",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "And for couples who waited until marriage, the silence can be even more noticeable." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "You can spend months planning the wedding. You discuss the venue. The guest list. The clothes. The food. The honeymoon. Where you’ll live. How you’ll combine your finances." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "You talk about almost everything." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Except the thing that many couples suddenly have to figure out when the wedding is over." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("blockquote", { children: "What happens when we’re finally alone?" })
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Divider, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "It sounds like something you’ll just figure out." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "And maybe you will." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "But imagine this." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "You’ve just gotten married. You’re exhausted from the wedding. You’re excited. You’re nervous. Your spouse is nervous too." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Neither of you really knows what the other person expects. Neither wants to say the wrong thing." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "So instead of talking… you both assume." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "thoughts",
						"aria-label": "Common assumptions",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "“They’ll probably be comfortable with this.”" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "“They’ll know what I want.”" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "“We’ll just figure it out.”" })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "And that’s where something interesting happens." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["You can love someone deeply… ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "and still completely misunderstand them." })] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Because your spouse cannot read your mind. And you cannot read theirs." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Love does not remove the need for language. In fact, love gives you a reason to speak more carefully—to ask instead of assuming, to listen without rushing, and to make room for an answer that may be different from your own." })
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Divider, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Your first night doesn’t have to be perfect." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "This is one of the biggest things newlywed couples need to understand." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Your first sexual experience may not look like the version you’ve imagined. It might be beautiful. It might be awkward. It might be exciting. It might be completely different from what you expected." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "And none of those things automatically means something is wrong." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "You’re not performing for an audience. You’re not taking an exam. You’re two people beginning to learn each other in a very vulnerable way." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "There is no prize for moving faster than either person is ready for. There is no shame in pausing, laughing, asking a question, changing your mind, or deciding that closeness tonight looks different from what you pictured." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "That’s why the better question isn’t:" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("blockquote", { children: "“Did we do it right?”" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "It’s:" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("blockquote", { children: "“Did we feel comfortable enough to communicate?”" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "That question is much more important." }) })
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Divider, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Because the real issue isn’t always sex." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Sometimes it’s communication." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "One person is nervous but doesn’t say anything. The other person doesn’t realize it. One person expects intimacy to happen frequently. The other needs more time." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "One person thinks something is completely normal. The other has never even considered it." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Neither person is necessarily wrong. They simply have different expectations." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Those expectations may come from family messages, faith, past experiences, things you heard from friends, or ideas absorbed without ever examining them. Even two people who share the same values can attach very different meanings to affection, initiation, rejection, frequency, and desire." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "And if nobody talks about those differences… they don’t magically disappear." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "They become assumptions. Then misunderstandings. Then frustration. And eventually, sometimes, resentment." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["A conversation cannot guarantee that every difference will disappear. But it can stop a difference from becoming a private story you tell yourself about your spouse: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", { children: "They don’t want me. They don’t care. I’m disappointing them. Something must be wrong with us." })] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Honest words give both people a chance to understand what is actually happening." })
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Divider, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Some of the most important words in a marriage sound very simple." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "simple-words",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "“I’m nervous.”" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "“Can we slow down?”" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "“I’m comfortable with this.”" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "“I’m not comfortable with that.”" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "“Can we talk about it?”" })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "These aren’t signs of a bad marriage. They’re signs that two people are actually learning how to communicate." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "And that matters because intimacy isn’t only physical." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "It’s trust. It’s vulnerability. It’s feeling safe enough to tell your spouse the truth." }) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "It’s knowing that you can say something uncomfortable without being mocked, pressured, or dismissed. It is also knowing how to hear your spouse’s honesty without turning it into a verdict on your worth." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "That kind of safety is not built by never having an awkward moment. It is built by what you do inside the awkward moment: whether you stay kind, whether you stay curious, and whether you protect the dignity of the person you married." })
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Divider, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "And then life happens." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "This is the part nobody can fully prepare you for." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Your first night is only one night. Your marriage may last decades." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Eventually there will be stressful seasons. Busy seasons. Pregnancy. Children. Fatigue. Changes in your body. Changes in desire. Health challenges." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "There may be times when one person wants intimacy and the other doesn’t. And moments when you don’t even know how to explain what’s wrong." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "The habits you build early matter here. If you learn that “not tonight” can be heard with tenderness, honesty becomes easier. If affection is not treated as a transaction, closeness has room to breathe. If questions are welcome, confusion does not have to become conflict." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "The question isn’t whether these things can happen. The question is:" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("blockquote", { children: "Will you know how to talk about them when they do?" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Because a healthy intimate relationship isn’t something you establish once on your wedding night." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "It’s something you keep building." }) })
				] })
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "author-band",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "page-shell",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "eyebrow",
						children: "A practical, compassionate guide"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", { children: ["That’s why I wrote ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", { children: "After “I Do.”" })] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "I didn’t want to create another book that simply tells couples that sex is important. You already know that." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["The bigger question is: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "How do you actually build a healthy intimate relationship inside a real marriage?" })] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "How do you talk about sex without embarrassment? How do you communicate what you need? What happens when you and your spouse have different levels of desire? How do you handle intimacy during stressful seasons?" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "How do you navigate difficult conversations? How do emotional connection and physical intimacy affect each other? And what do you do when something isn’t working?" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "These are the conversations that don’t always happen before marriage. But they matter enormously after it." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "This book brings those conversations into the open with warmth and honesty. It does not ask you to compare your marriage with anyone else’s. It helps you pay attention to the two people actually inside your marriage." })
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "contents",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "page-shell",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "eyebrow",
						children: "Inside the book"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "A framework for understanding, communicating, and growing together" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", { children: "After “I Do”" }), " was created for couples who don’t want to leave one of the most important parts of their marriage to guesswork."] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Inside, you’ll explore the conversations and principles that support healthy intimacy—not only at the beginning of marriage, but through the ordinary changes that come later." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "contents-list",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Starting the conversation:" }), " how to speak about intimacy with less embarrassment and more honesty."] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Understanding expectations:" }), " how unspoken ideas can create distance, even when both spouses mean well."] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Building emotional safety:" }), " creating room for questions, boundaries, vulnerability, and truthful answers."] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Navigating different levels of desire:" }), " approaching differences as something to understand together, not a contest to win."] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Handling real-life seasons:" }), " keeping communication open through stress, fatigue, pregnancy, children, health changes, and shifting routines."] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Strengthening connection:" }), " understanding how emotional closeness and physical intimacy can influence each other."] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Knowing when something isn’t working:" }), " recognizing difficulties and responding with patience instead of silence or blame."] })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Conversations you can return to as your marriage changes" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "A useful conversation about intimacy is rarely a single, dramatic talk. More often, it is a series of smaller conversations: a check-in after a tiring week, an honest answer when something feels unfamiliar, a question asked gently instead of an assumption made in silence." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "The book helps you make space for those conversations before frustration becomes the only language available. It invites both spouses to describe their experience without turning the discussion into blame, pressure, or a comparison with someone else’s marriage." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "You can use the ideas privately to understand your own expectations. You can also read and discuss them together, taking one subject at a time. The aim is not to force instant agreement. It is to help you understand what each person means, needs, fears, and hopes for." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Some seasons will call for patience. Others will call for courage. Some may require support beyond what a book can offer. Knowing that is not failure. A healthy framework helps you recognize when a caring conversation is enough and when it may be wise to speak with a qualified professional." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "It won’t promise you a perfect marriage. It won’t tell you that every couple will experience intimacy the same way. And it won’t pretend that one book can solve every problem." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["Instead, it gives you something much more useful: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "a framework for talking, listening, understanding, and growing together." })] })
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "offer-band",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "page-shell offer-grid",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("figure", {
					className: "offer-book",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: after_i_do_book_png_asset_default.url,
						alt: "After I Do hardcover book mockup",
						width: "768",
						height: "1152",
						loading: "lazy"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "offer-copy",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "eyebrow",
							children: "After “I Do”"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "The complete guide to sex, intimacy, and building a healthy sexual relationship in marriage" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "This is a digital guide you can read privately, return to when a conversation feels difficult, and work through at a pace that respects both you and your spouse." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "price",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Get the complete book for" }), "₦3,700"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PurchaseButton, { label: "Get After I Do" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "checkout-note",
							children: "Secure checkout provided by Selar."
						})
					]
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "page-shell honest-section",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "eyebrow",
					children: "What you’re really getting"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Not a shortcut. A better way to keep talking." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "There are no exaggerated promises here, and no bonus stack designed to make the offer look bigger than it is." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
					"You are getting the complete ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", { children: "After “I Do”" }),
					" guide: thoughtful support for the conversations that can shape trust, comfort, and connection across your marriage."
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Read it before marriage and use it to begin honest conversations. Read it as newlyweds when everything feels new. Return to it later when life changes and the words are harder to find." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "The goal is not to give you a script for a perfect relationship. It is to help you build the confidence to speak, listen, ask, and learn—together." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PurchaseButton, { label: "Get the Complete Guide for ₦3,700" })
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "closing-band",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "page-shell closing",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "eyebrow",
						children: "For the life after the wedding"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "You don’t have to know everything before you get married." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "You just need to be willing to learn." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Learn your spouse. Learn how to communicate. Learn how to handle differences. Learn how to talk about difficult things. And learn how to build intimacy that goes beyond the wedding night." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Because your wedding day is one day." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("blockquote", { children: "Your marriage is everything that comes after." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "The conversations you have after the wedding may shape your marriage more than the wedding itself." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PurchaseButton, { label: "Get After I Do Now" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "final-note",
						children: "A warm, honest guide for real conversations in a real marriage."
					})
				]
			})
		})
	] });
}
//#endregion
export { SalesPage as component };
