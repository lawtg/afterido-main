//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DBOD4FpL.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/Users/thankgod/Documents/PDF INCOME/Before I do/afterido-main/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-DD9oU_BW.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DD9oU_BW.js"
		} }]
	},
	"/": {
		filePath: "/Users/thankgod/Documents/PDF INCOME/Before I do/afterido-main/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-RcjLQqY2.js"]
	}
} });
//#endregion
export { tsrStartManifest };
